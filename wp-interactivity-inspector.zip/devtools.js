(()=>{chrome.devtools.panels.create("WP Interactivity",null,"panel.html",function(e){});})();
//# sourceMappingURL=devtools.js.map
