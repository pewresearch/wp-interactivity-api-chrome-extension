(()=>{var a=document.getElementById("element-list"),l=document.getElementById("refresh");function r(){chrome.devtools.inspectedWindow.eval(`(() => {
      const nodes = Array.from(document.querySelectorAll('*')).filter(el =>
        Array.from(el.attributes).some(attr => /^data-wp-/.test(attr.name))
      );
      return nodes.map(el => {
        let path = [];
        let node = el;
        while (node && node.nodeType === Node.ELEMENT_NODE) {
          let name = node.nodeName.toLowerCase();
          if (node.id) {
            name += '#' + node.id;
            path.unshift(name);
            break;
          }
          const siblings = Array.from(node.parentNode?.children || []);
          const sameTag = siblings.filter(n => n.nodeName === node.nodeName);
					if (sameTag.length > 1) {
						const idx = sameTag.indexOf(node) + 1;
						name += ':nth-of-type(' + idx + ')';
					}
					path.unshift(name);
					node = node.parentNode;
        }
        const directives = Array.from(el.attributes)
          .filter(a => /^data-wp-/.test(a.name))
          .map(a => ({ name: a.name, value: a.value }));
        return { selector: path.join(' > '), directives };
      });
    })()`,(d,t)=>{if(t){console.error(t);return}a.innerHTML="",d.forEach(e=>{let n=document.createElement("li");n.textContent=`${e.selector}: ${e.directives.map(o=>`${o.name}="${o.value}"`).join(" ")}`,n.addEventListener("click",()=>{chrome.devtools.inspectedWindow.eval(`inspect(document.querySelector('${e.selector.replace(/'/g,"\\'")}'));`)}),a.appendChild(n)})})}l.addEventListener("click",r);chrome.devtools.panels.onShown.addListener(r);})();
//# sourceMappingURL=panel.js.map
